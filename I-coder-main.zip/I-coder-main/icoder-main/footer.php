  <div class="mt-5 pt-5 pb-5 footer">
<div class="container1">
  <div class="row">
  <div class="col-lg-4 col-xs-12 location">
      <h4 class="mt-lg-0 mt-sm-4 text-center" >iCoder</h4>
      <pre>
      <i>
      This is a online platform which provide a 
      very simple and straight forword path to 
      those who are new in coding or in programming. 
      
      Any fool can write code that a computer can
      understand. 
      Good programmers write code that humans can
      understand.
    </i>
      </pre>
  </div>
    <div class="col-lg-3 col-xs-12 links">
      <h4 class="mt-lg-0 mt-sm-3 text-center">Links</h4>
        <ul class="m-0 p-0">
          <li>- <a href="www.instagram.com">Instagram</a></li>
          <li>- <a href="www.Linkedin.com">Linkedin</a></li>
          <li>- <a href="www.Twitter.com">Twitter</a></li>
          <li>- <a href="www.Facebook.com">Facebook</a></li>
        </ul>
    </div>
    <div class="col-lg-4 col-xs-12 location">
      <h4 class="mt-lg-0 mt-sm-4 text-center">Contact us</h4>
      


      <p class="mb-0"><i class="fa fa-phone mr-3"></i>Phone No - +916396267480, +919328347795</p>
      <p><i class="fa fa-envelope-o mr-3"></i>Email - 2019017@iiitdmj.ac.in, 2019014@iiitdmj.ac.in</p>
    </div>
  </div>
  <div class="row mt-5">
    <div class="col copyright">
      <p class="text-center"><small class="text-dark-50"><h3 class="text-center">© 2020.All Rights Reserved to Aman_Akshat Project.</h3></small></p>
    </div>
  </div>
</div>
</div>

<!-- <p>This is a online platform which provide a very simple and straight forword path to those who are new in coding or in programming</p> -->

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
