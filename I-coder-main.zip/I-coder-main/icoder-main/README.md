<img width="1700" alt="Screenshot 2024-08-31 at 9 39 32 PM" src="https://github.com/user-attachments/assets/afc33a1f-9acb-4a6f-8a0e-3b61fbaf01e5">
<img width="1549" alt="Screenshot 2024-08-31 at 9 39 51 PM" src="https://github.com/user-attachments/assets/bcf55044-e057-458c-96a4-5de76e587a8e">
<img width="1537" alt="Screenshot 2024-08-31 at 9 40 07 PM" src="https://github.com/user-attachments/assets/8888286c-dd58-488f-ab54-72542d9faa20">
<img width="1476" alt="Screenshot 2024-08-31 at 9 40 19 PM" src="https://github.com/user-attachments/assets/a7fa2360-9630-4ed1-bcc4-c81bdb98f515">
<img width="1339" alt="Screenshot 2024-08-31 at 9 40 56 PM" src="https://github.com/user-attachments/assets/4cb47212-dcba-41ce-8f2f-98c94a7004ba">
